# 已踩坑与修复（务必避免重犯）

## 全局 const 重声明（最高频致命坑）
engine.js 顶层 `const W/H/FPS/TOTAL/SEGS/...` 与页面 inline <script> 的同名 `const` 处于**同一全局词法 scope** →
`SyntaxError: Identifier 'X' has already been declared`，整段 inline 脚本死掉（页面停摆、控件无响应、0 渲染）。
修复：页面 inline 侧改名（如 FPS→FPSV、SEGS→SEGL、TOTAL→TOT），或引擎改用 IIFE/模块封装只暴露 window.X。
验收时若见"控件全失效 + 控制台 SyntaxError"，先查此项。

## 帧→段/时代映射 off-by-one
renderSceneTo(target, idx, u) 的 idx 语义务必统一（era index 0..N-1 vs seg=era+1）。
混用会导致"点彩页签渲染出新艺术帧"。定义单一 segOf(i) 返回 {kind, era, u}，渲染与代码页签共用。

## renderFrame 重置 transform
renderFrame(i) 内部 setTransform(1,0,0,1,0,0) 以 1080xH 坐标绘制 → 直接用于小 canvas 会溢出。
工作台/retrospection 页改用 renderSceneTo(ctx, seg, u)（不重置 transform），调用前自设 scale=canvas.width/1080。
若需 intro/outro，引擎须暴露 renderIntro/renderOutro 并先 E.init(stageCanvas) 使模块 ctx 指向舞台。

## AudioContext autoplay
headless/无手势时 AC.state='suspended'。首次 pointerdown/keydown 调 ensureAudio() resume。
默认 soundOn=true + 顶栏一键静音显示状态；静音用 master.gain.setTargetAtTime。

## 确定性随机
每帧 Math.random() 会闪烁。预计算种子化数组（mulberry32）于模块加载期；帧内只读。
纹理/碎片/墨点/色点皆预计算；帧内仅做变换与裁剪。

## 舔爪/多相位窗口重叠
lift 与 lick 区间若重叠（如 l1=k0+0.05）会导致舌头只有极短窗口。相位表用互斥区间 [d0,d1)[d1,h1)[l0,l1)[k0,k1)。

## 姿态物理合理
- 够高处把手必须**竖直起跳**（spine 垂直、前爪上伸、后腿下垂），不可横身斜扑。
- 舀水应**站在桌上**够同一桌面的杯/碗，而非坐地够凳子。
- 跨场景动链衔接：上一段结束位置=下一段起始位置（如走到门口 x 与开门段 idle x 一致）。
- 加 anticipation（蓄力 squash）、follow-through（尾/耳滞后）、contact shadow、落地 squash。

## 容器语义
用户说"杯子"就用带把陶瓷杯，说"碗"才用碗；跟随最新一次表述。

## 验收必跑
冒烟帧→Read 联系表目检→修→全量→ffprobe+抽帧目检；工作台用 cdp-eval 跑控件/导出/播放/移动/0 错误。
不要声称未跑过的检查。