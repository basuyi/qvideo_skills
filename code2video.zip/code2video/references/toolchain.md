# 本机已验证工具链（macOS，lupan.ms）

PATH 无 node/npm/ffmpeg。用以下绝对路径，勿假设全局命令。

## Node（v24，含 fetch/WebSocket）
ELECTRON_RUN_AS_NODE=1 "/Applications/Qoder.app/Contents/MacOS/Qoder" <script.js> [args]
- 零依赖 CDP 驱动、静态服务、WAV 合成皆可用此运行。
- node-repl MCP 仅限 Browser/Computer Use SDK 脚本，不作通用脚本运行时。

## ffmpeg 4.4（含 libx264/libx265/libfreetype）
"/Users/lupan.ms/Library/Application Support/bilibili/ffmpeg/ffmpeg"
- 编码: -framerate 30 -i frames/f%04d.png -i audio.wav -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -c:a aac -b:a 160k -shortest -movflags +faststart out.mp4
- 联系表: -framerate 1 -i sheet/s%02d.png -vf "scale=W:H,tile=CxR" -frames:v 1 sheet.png
- 抽帧: -ss <t> -i out.mp4 -frames:v 1 f.png
- 探测: -i out.mp4 2>&1 | grep -E "Duration|Stream"
- drawtext 中文字体: /Library/Fonts/Alibaba-PuHuiTi-Medium.otf（单 face OTF 稳）。
  /System/Library/Fonts/PingFang.ttc 报 "cannot open resource"，勿用。

## headless Chrome（CDP 逐帧）
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
  --headless=new --remote-debugging-port=<port> --user-data-dir=<tmp>
  --window-size=<W>,<H> --hide-scrollbars --force-device-scale-factor=1
  --no-first-run --disable-extensions file://<page.html>
- /json/list 取 page 的 webSocketDebuggerUrl；Node 全局 WebSocket 连接。
- Runtime.evaluate 调 renderFrame(i)；Page.captureScreenshot{format:'png'} 取 base64 落盘。
- Emulation.setDeviceMetricsOverride 设定 W/H/dpr=1。
- 1080p 约 0.05–0.3 s/帧；竖屏 1080x1920 类似。
- 经典 <script src> 在 file:// 可跨目录加载；ES module 被 CORS 挡，需本地 http 服务。
- 页面须暴露 window.renderFrame(i)、window.__meta={fps,frames,w,h}、window.__ready=true。
- headless 无 vsync 时 rAF 可能节流；fps 计量用 wall-clock raw dt，勿用 clamp 后的 dt。

## 端口约定
多实例并行渲染/验收时用不同端口（如 9333/9344/9355/9366/9377/9388/9399/9401/9402），避免冲突。

## 网络
办公网出口时段限流约 0.5MB/s；jsdelivr CDN 可下 three.module.js（r160 约 670KB）。
重启会清后台进程与 /tmp；长任务用 run_in_background 或 nohup。