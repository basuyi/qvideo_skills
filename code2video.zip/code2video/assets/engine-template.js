"use strict";
/* 通用 code2video 引擎模板（主题无关的最小可运行示例： kinetic shapes ）。
   契约：window.renderFrame(i) 为帧号纯函数；window.__meta={fps,frames,w,h}；window.__ready=true。
   替换 renderScene 内的绘制为你的主题渲染器；保持"每帧=f(t)"与确定性种子随机。 */
const W = 1080, H = 1920, FPS = 30;
const INTRO = 1.5, MAIN = 6.0, OUTRO = 1.5;
const TOTAL = INTRO + MAIN + OUTRO;
const FRAMES = Math.round(TOTAL * FPS);
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
let ctx = null;
function init(c) { ctx = c.getContext('2d'); }
const P = { count: 7, speed: 1, hue: 36, glow: 0.6, grain: 0.4 };
const P_RANGE = { count: [3, 14], speed: [0.25, 2], hue: [0, 360], glow: [0, 1], grain: [0, 1] };
function setParams(p) { for (const k in P) if (p && typeof p[k] === 'number') { const r = P_RANGE[k]; P[k] = k === 'count' ? Math.round(clamp(p[k], r[0], r[1])) : clamp(p[k], r[0], r[1]); } }
function resetParams() { setParams({ count: 7, speed: 1, hue: 36, glow: 0.6, grain: 0.4 }); }
const DOTS = (() => { const r = mulberry32(7); const o = []; for (let i = 0; i < 200; i++) o.push({ x: r(), y: r(), s: r() }); return o; })();
function ellipse(x, y, rx, ry) { ctx.beginPath(); ctx.ellipse(x, y, Math.max(.5, rx), Math.max(.5, ry), 0, 0, 7); ctx.fill(); }
function renderScene(u) {
  // 背景：深色 + 漂移光晕
  ctx.fillStyle = '#14121a'; ctx.fillRect(0, 0, W, H);
  const g = ctx.createRadialGradient(W * 0.3, H * 0.3, 0, W * 0.3, H * 0.3, W * 0.9);
  g.addColorStop(0, 'hsla(' + P.hue + ',70%,50%,0.20)'); g.addColorStop(1, 'transparent');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  // 轨道形状（主题无关示例）
  const n = P.count;
  for (let i = 0; i < n; i++) {
    const a = u * P.speed * 0.9 + i / n * Math.PI * 2;
    const rr = W * (0.16 + 0.10 * Math.sin(u * 0.7 + i));
    const x = W / 2 + Math.cos(a) * rr, y = H * 0.45 + Math.sin(a) * rr * 0.6;
    const hue = (P.hue + i * 24) % 360;
    ctx.save();
    ctx.shadowColor = 'hsla(' + hue + ',80%,60%,0.9)'; ctx.shadowBlur = 30 * P.glow;
    ctx.fillStyle = 'hsl(' + hue + ',75%,60%)';
    ellipse(x, y, W * 0.035 * (1 + 0.2 * Math.sin(u * 2 + i)), W * 0.035);
    ctx.restore();
  }
  // 颗粒
  if (P.grain > 0.02) {
    ctx.fillStyle = 'rgba(244,242,236,' + (0.05 * P.grain) + ')';
    for (const d of DOTS) ctx.fillRect(d.x * W, d.y * H, 1.5, 1.5);
  }
  // 字幕条（每场景说明示例）
  ctx.fillStyle = 'rgba(20,18,26,0.7)'; ctx.fillRect(0, H * 0.90, W, H * 0.06);
  ctx.fillStyle = '#f4f2ec'; ctx.font = '700 34px "Helvetica Neue","PingFang SC",sans-serif';
  ctx.fillText('通用 code2video 引擎模板 · 每帧 = f(t)', W * 0.06, H * 0.94);
}
function renderIntro(u) {
  ctx.fillStyle = '#14121a'; ctx.fillRect(0, 0, W, H);
  ctx.globalAlpha = smooth(u / 0.4);
  ctx.fillStyle = 'hsl(' + P.hue + ',75%,60%)'; ctx.fillRect(W * 0.1, H * 0.34, W * 0.14 * smooth(u / 0.3), 8);
  ctx.fillStyle = '#f4f2ec'; ctx.font = '900 84px Georgia,"Songti SC",serif';
  ctx.fillText('code2video', W * 0.1, H * 0.44);
  ctx.font = '500 36px "Helvetica Neue","PingFang SC",sans-serif'; ctx.fillStyle = '#b8b2c8';
  ctx.fillText('固定代码渲染 · 非生成式', W * 0.1, H * 0.50);
  ctx.globalAlpha = 1;
}
function renderOutro(u) {
  ctx.fillStyle = '#14121a'; ctx.fillRect(0, 0, W, H);
  ctx.globalAlpha = smooth(u / 0.35);
  ctx.fillStyle = '#f4f2ec'; ctx.font = '900 72px Georgia,"Songti SC",serif';
  ctx.fillText('每帧 = f(t)', W * 0.1, H * 0.44);
  ctx.fillStyle = 'hsl(' + P.hue + ',75%,60%)'; ctx.font = '500 32px "SF Mono",Menlo,monospace';
  ctx.fillText('100% procedural · 0 generative models', W * 0.1, H * 0.50);
  ctx.globalAlpha = 1;
}
function renderFrame(i) {
  const t = i / FPS;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, W, H);
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.globalAlpha = 1; ctx.shadowBlur = 0;
  if (t < INTRO) renderIntro(t);
  else if (t < INTRO + MAIN) renderScene(t - INTRO);
  else renderOutro(t - INTRO - MAIN);
}
function renderSceneTo(target, seg, u) {
  const prev = ctx; ctx = target;
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.globalAlpha = 1; ctx.shadowBlur = 0;
  if (seg === 0) renderIntro(u); else if (seg === 1) renderScene(u); else renderOutro(u);
  ctx = prev;
}
window.Code2VideoEngine = { init, renderFrame, renderSceneTo, params: P, ranges: P_RANGE, setParams, resetParams, meta: { fps: FPS, frames: FRAMES, w: W, h: H, total: TOTAL } };
window.renderFrame = renderFrame;
window.__meta = { fps: FPS, frames: FRAMES, w: W, h: H, total: TOTAL };
window.__ready = true;
const __cv = document.getElementById('c');
if (__cv) { init(__cv); renderFrame(0); }