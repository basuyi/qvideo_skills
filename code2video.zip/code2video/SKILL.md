---
name: code2video
description: Generate videos purely from executable code (Canvas2D/WebGL/Three.js/SVG), never from generative video models. Use when the user says code2video, 用代码生成视频, 代码做视频, 程序化动画, 多风格/多时代动画, 复刻某视频风格用代码, manim 式科普动画, or asks to turn a brief/reference clip into a code-rendered film. Covers the verified local toolchain (Qoder Electron as Node24, headless Chrome CDP per-frame capture, bilibili ffmpeg4.4, Node-synthesized WAV), the smoke-frame review loop, physically-plausible continuous choreography, and the three-piece delivery (film + parameter workbench + source↔frame verifier). Subject-agnostic (not cat-specific).
---

# code2video

Render film as code: every frame is a pure function of its frame index. No generative video/image model substitutes for frames. Deliver film + live parameter workbench + source↔frame verifier.

## Hard constraints

- Every frame and all motion computed by code (Canvas2D / WebGL / Three.js / SVG). Never call VideoGen / wan / text-to-video to produce frames.
- "实景/照片级" means photoreal *look*: photo baseplate + 2.5D depth-mesh parallax + code particles/camera/grain. Disclose boundaries (photo layer doesn't walk, depth-edge stretch, limited camera range). Generative models at most for static baseplate, disclosed.
- Deterministic: seeded RNG precomputed at load; frame code only transforms/clips. Same index → same frame.
- Physically plausible, continuous choreography (see references/choreography.md).

## Toolchain (verified; absolute paths, PATH lacks node/ffmpeg)

Read references/toolchain.md for exact commands. Summary:
- Node: `ELECTRON_RUN_AS_NODE=1 "/Applications/Qoder.app/Contents/MacOS/Qoder" script.js`
- ffmpeg: `"/Users/lupan.ms/Library/Application Support/bilibili/ffmpeg/ffmpeg"`
- Chrome: `"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --remote-debugging-port=<p> ...`
- drawtext CJK font: `/Library/Fonts/Alibaba-PuHuiTi-Medium.otf` (PingFang.ttc fails).

## Workflow

1. **Brief → SPEC.** Write subject, segments/eras, per-scene technique, shared choreography beats, audio design, acceptance. This brief is the only natural-language input; it becomes code, not a video-model prompt.
2. **Engine.** Start from `assets/engine-template.js` (subject-agnostic, runnable). Implement subject renderers in `renderScene`; keep contract `window.renderFrame(i)`, `window.__meta={fps,frames,w,h}`, `window.__ready`, plus `renderSceneTo(ctx,seg,u)` and exposed `renderIntro/renderOutro` for workbench reuse. Single `segOf(i)` mapping shared by render and code-tabs (avoid off-by-one).
3. **Smoke frames.** `scripts/cdp-render.js <page.html> <outDir> <list|start-end|all> [port] [w] [h]`; then `scripts/make-sheet.js <outDir> <list> <cols> <rows> <cw> <ch> <out.png>`; **Read the sheet** and inspect composition/action/clipping/caption legibility.
4. **Fix → re-verify** affected frames. Repeat until clean. Read references/pitfalls.md before debugging (global-const redeclaration, transform reset, off-by-one, autoplay, phase-window overlap are the recurrent killers).
5. **Full render.** `cdp-render.js ... all`. Confirm count == meta.frames.
6. **Audio.** Synthesize with `scripts/synth-lib.js` (require it): relaxed procedural bed (lo-fi / waltz / music-box) + event SFX timed to exact event frames (crash/tap/water/handle/creak/steps). Normalize to 0.85 peak. No external audio assets.
7. **Encode.** ffmpeg H.264 crf18 yuv420p + AAC 160k + faststart (command in toolchain.md). ffprobe Duration/resolution/fps/streams; extract spot frames incl. key trigger frames and Read them.
8. **Workbench page.** Single-file html + engine script src. ≥7 live controls in a permanently visible rail (scrub/steppers/play/speed, segment chips + live mini-canvas thumbs, ≥4 look/render sliders, toggles, reset/random/export PNG/export JSON). Top one-click mute (default on, shows state); sound tied to visible events. Scene-description strip + beat badge live. Own-palette scrollbars; mobile stack, no overflow. Theme palette derived from subject (7–8 hues).
9. **Source↔frame page.** `scripts/build-source.js <engine.js> <out.js> <fnNames> [extraFiles]` extracts real code; page shows live frame left + highlighted real source right with code-sync toggle, pipeline commands, and BRIEF tab. Proves "fixed code, not prompt".
10. **Verify pages.** `scripts/cdp-eval.js <page> <port> <out.png> [exprs...]` exercises controls/export/play/mobile and reports console errors; Read screenshots for desktop + mobile. Repair every observable defect, rerun affected flow.

## Delivery

Return three links: film mp4, workbench html, source↔frame html. State verification actually performed (smoke sheet, full frame count, ffprobe, spot frames, page runtime 0-error). Never claim unrun checks. See references/deliverables.md for the acceptance checklist.

## Resources

- scripts/cdp-render.js — zero-dep CDP per-frame capture (tested)
- scripts/make-sheet.js — ffmpeg contact sheet for review (tested)
- scripts/cdp-eval.js — page runtime acceptance + screenshot + console errors (tested)
- scripts/build-source.js — extract real engine source → source-data.js (tested)
- scripts/synth-lib.js — procedural WAV synth library (tested)
- assets/engine-template.js — runnable subject-agnostic engine honoring the frame contract (tested)
- references/toolchain.md — exact paths/commands/fonts/ports
- references/pitfalls.md — recurrent bugs + fixes
- references/choreography.md — physical plausibility, continuity,造型 iteration, multi-style techniques
- references/deliverables.md — three-piece spec + acceptance checklist