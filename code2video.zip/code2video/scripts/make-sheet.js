// 通用联系表拼接（ffmpeg tile），供回看冒烟帧
// 用法: ELECTRON_RUN_AS_NODE=1 Qoder make-sheet.js <framesDir> <frameListComma> <cols> <rows> <cellW> <cellH> <outPng>
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const FFMPEG = '/Users/lupan.ms/Library/Application Support/bilibili/ffmpeg/ffmpeg';
const [dir, listArg, cols, rows, cw, ch, out] = process.argv.slice(2);
if (!dir || !listArg || !out) { console.error('usage: make-sheet.js <framesDir> <list> <cols> <rows> <cellW> <cellH> <outPng>'); process.exit(1); }
const list = listArg.split(',').map(Number);
const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'sheet-'));
list.forEach((f, k) => fs.copyFileSync(path.join(dir, 'f' + String(f).padStart(4, '0') + '.png'), path.join(tmp, 's' + String(k).padStart(2, '0') + '.png')));
try {
  execFileSync(FFMPEG, ['-y', '-framerate', '1', '-i', path.join(tmp, 's%02d.png'), '-vf', 'scale=' + cw + ':' + ch + ',tile=' + cols + 'x' + rows, '-frames:v', '1', out], { stdio: 'pipe' });
  console.log('OK sheet -> ' + out + '  (' + list.length + ' frames, ' + cols + 'x' + rows + ')');
} catch (e) {
  console.error('FAIL ffmpeg: ' + (e.stderr ? e.stderr.toString().slice(-400) : e.message)); process.exit(1);
} finally { fs.rmSync(tmp, { recursive: true, force: true }); }