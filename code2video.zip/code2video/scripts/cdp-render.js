// 通用 code2video 逐帧渲染驱动（零依赖，Node-as-Electron 运行）
// 用法: ELECTRON_RUN_AS_NODE=1 "/Applications/Qoder.app/Contents/MacOS/Qoder" cdp-render.js <page.html> <outDir> <framesSpec> [port] [width] [height]
//   framesSpec: "all" | "start-end" | "0,12,48"
// 页面须暴露 window.renderFrame(i) 与 window.__meta={fps,frames,w,h}；经典 <script>（非 ES module）以便 file:// 加载。
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const [page, outDir, spec, portArg, wArg, hArg] = process.argv.slice(2);
if (!page || !outDir || !spec) { console.error('usage: cdp-render.js <page.html> <outDir> <all|start-end|list> [port] [w] [h]'); process.exit(1); }
const PORT = parseInt(portArg || '9333', 10);
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function main() {
  const abs = path.resolve(page);
  fs.mkdirSync(outDir, { recursive: true });
  const chrome = spawn(CHROME, [
    '--headless=new', '--remote-debugging-port=' + PORT,
    '--user-data-dir=' + path.join(outDir, '.chrome-profile'),
    '--window-size=1080,1920', '--hide-scrollbars', '--force-device-scale-factor=1',
    '--no-first-run', '--disable-extensions', '--disable-background-networking',
    'file://' + abs
  ], { stdio: 'ignore' });
  let targets = null;
  for (let i = 0; i < 50; i++) {
    await sleep(200);
    try { targets = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json(); break; } catch (e) {}
  }
  if (!targets) { console.error('FAIL devtools unreachable on port ' + PORT); chrome.kill(); process.exit(1); }
  const pg = targets.find(t => t.type === 'page' && t.url.includes(path.basename(abs))) || targets.find(t => t.type === 'page');
  const ws = new WebSocket(pg.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0; const pending = new Map();
  ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } };
  const send = (method, params) => new Promise(res => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params: params || {} })); });
  const evaluate = async expr => {
    const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true });
    if (r.result && r.result.exceptionDetails) throw new Error('page exception: ' + JSON.stringify(r.result.exceptionDetails.exception || r.result.exceptionDetails.text));
    return r.result && r.result.result ? r.result.result.value : undefined;
  };
  await send('Page.enable');
  for (let i = 0; i < 50; i++) { if (await evaluate('window.__ready === true')) break; await sleep(150); }
  const meta = await evaluate('window.__meta');
  if (!meta) { console.error('FAIL page missing window.__meta / __ready'); chrome.kill(); process.exit(1); }
  const W = parseInt(wArg || meta.w, 10), H = parseInt(hArg || meta.h, 10);
  await send('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: 1, mobile: false });
  let list;
  if (spec === 'all') list = Array.from({ length: meta.frames }, (_, k) => k);
  else if (spec.includes('-')) { const [a, b] = spec.split('-').map(Number); list = Array.from({ length: b - a + 1 }, (_, k) => a + k); }
  else list = spec.split(',').map(Number);
  const t0 = Date.now();
  for (let k = 0; k < list.length; k++) {
    const i = list[k];
    await evaluate('renderFrame(' + i + ')');
    const shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.join(outDir, 'f' + String(i).padStart(4, '0') + '.png'), Buffer.from(shot.result.data, 'base64'));
    if (k % 120 === 0) console.log('frame ' + i + '  ' + ((Date.now() - t0) / 1000).toFixed(1) + 's');
  }
  console.log('OK ' + list.length + ' frames -> ' + outDir + '  (' + ((Date.now() - t0) / 1000).toFixed(1) + 's, ' + W + 'x' + H + ')');
  await send('Browser.close').catch(() => {});
  ws.close(); chrome.kill(); process.exit(0);
}
main().catch(e => { console.error('FAIL ' + (e && e.message || e)); process.exit(1); });