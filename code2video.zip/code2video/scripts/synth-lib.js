// 通用程序化音轨合成库（Node-as-Electron require 使用）
// const S = require('<skill>/scripts/synth-lib.js');
// const { L, R } = S.buffer(24.6);  S.voice(L,R,f,t0,dur,vol,dec,pan,kind); S.noise(...); S.write(L,R,dur,'audio.wav');
const SR = 44100;
function buffer(dur) { const n = Math.round(SR * dur); return { L: new Float32Array(n), R: new Float32Array(n), n }; }
function add(L, R, i, v, pan) {
  if (i < 0 || i >= L.length) return;
  L[i] += v * Math.cos((pan + 1) * Math.PI / 4);
  R[i] += v * Math.sin((pan + 1) * Math.PI / 4);
}
// kind: sine|rhodes|box|bell|metal|harpsi|drop
function voice(L, R, f, t0, dur, vol, dec, pan, kind) {
  const s0 = Math.round(t0 * SR), len = Math.round(dur * SR);
  for (let i = 0; i < len; i++) {
    const t = i / SR;
    let v = Math.sin(2 * Math.PI * f * t);
    if (kind === 'rhodes') v += 0.35 * Math.sin(2 * Math.PI * f * 2.003 * t) * Math.exp(-t * 3) + 0.14 * Math.sin(2 * Math.PI * f * 3.01 * t) * Math.exp(-t * 5);
    if (kind === 'box') v += 0.45 * Math.sin(2 * Math.PI * f * 4.01 * t) * Math.exp(-t * 12) + 0.18 * Math.sin(2 * Math.PI * f * 9.2 * t) * Math.exp(-t * 24);
    if (kind === 'bell') v += 0.4 * Math.sin(2 * Math.PI * f * 2.76 * t) * Math.exp(-t * 5) + 0.25 * Math.sin(2 * Math.PI * f * 5.4 * t) * Math.exp(-t * 8);
    if (kind === 'metal') v += 0.5 * Math.sin(2 * Math.PI * f * 1.5 * t) * Math.exp(-t * 18) + 0.3 * Math.sin(2 * Math.PI * f * 2.9 * t) * Math.exp(-t * 24);
    if (kind === 'harpsi') v += 0.5 * Math.sin(2 * Math.PI * f * 2 * t) * Math.exp(-t * 7) + 0.3 * Math.sin(2 * Math.PI * f * 3.01 * t) * Math.exp(-t * 10);
    if (kind === 'drop') { const ff = f * (1 + 1.6 * Math.exp(-t * 22)); v = Math.sin(2 * Math.PI * ff * t); }
    add(L, R, s0 + i, v * Math.min(1, t / 0.004) * Math.exp(-t * dec) * vol, pan || 0);
  }
}
// shape: decay|swell|slurp ; lp>0 做一阶低通
function noise(L, R, t0, dur, vol, lp, pan, shape, rng) {
  const s0 = Math.round(t0 * SR), len = Math.round(dur * SR);
  let last = 0; const a = lp ? Math.exp(-2 * Math.PI * lp / SR) : 0;
  for (let i = 0; i < len; i++) {
    const t = i / SR, p = i / len;
    let w = rng() * 2 - 1;
    if (lp) { last = a * last + (1 - a) * w; w = last; }
    const e = shape === 'swell' ? Math.sin(Math.PI * p) : (shape === 'slurp' ? Math.sin(Math.PI * p) * (1 + 0.5 * Math.sin(2 * Math.PI * 9 * t)) : Math.exp(-t * 30));
    add(L, R, s0 + i, w * e * vol, pan || 0);
  }
}
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function write(L, R, dur, file) {
  const n = L.length;
  let peak = 0;
  for (let i = 0; i < n; i++) peak = Math.max(peak, Math.abs(L[i]), Math.abs(R[i]));
  const g = peak > 0 ? 0.85 / peak : 1;
  const buf = Buffer.alloc(44 + n * 4);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + n * 4, 4); buf.write('WAVE', 8);
  buf.write('fmt ', 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(2, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 4, 28); buf.writeUInt16LE(4, 32); buf.writeUInt16LE(16, 34);
  buf.write('data', 36); buf.writeUInt32LE(n * 4, 40);
  const c = v => Math.max(-32767, Math.min(32767, Math.round(v * 32767)));
  for (let i = 0; i < n; i++) { buf.writeInt16LE(c(L[i] * g), 44 + i * 4); buf.writeInt16LE(c(R[i] * g), 46 + i * 4); }
  require('fs').writeFileSync(file, buf);
  return { peak, gain: g, seconds: dur };
}
module.exports = { SR, buffer, add, voice, noise, mulberry32, write };