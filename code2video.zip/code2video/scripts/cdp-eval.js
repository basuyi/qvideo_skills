// 通用页面运行时验收（CDP）：顺序执行 JS 表达式、收集控制台错误、末尾截图
// 用法: ELECTRON_RUN_AS_NODE=1 Qoder cdp-eval.js <page.html> <port> <outPng> [expr1] [expr2] ...
// 每个 expr 的返回值打印为一行 JSON；表达式里可用 document/window。末尾截图存 outPng。
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const [page, portArg, outPng, ...exprs] = process.argv.slice(2);
if (!page || !outPng) { console.error('usage: cdp-eval.js <page.html> <port> <outPng> [exprs...]'); process.exit(1); }
const PORT = parseInt(portArg || '9344', 10);
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function main() {
  const abs = path.resolve(page);
  const chrome = spawn(CHROME, [
    '--headless=new', '--remote-debugging-port=' + PORT,
    '--user-data-dir=' + path.join(path.dirname(outPng), '.chrome-eval'),
    '--window-size=1440,1000', '--hide-scrollbars', '--force-device-scale-factor=1',
    '--no-first-run', '--disable-extensions', 'file://' + abs
  ], { stdio: 'ignore' });
  let targets = null;
  for (let i = 0; i < 50; i++) {
    await sleep(200);
    try { targets = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json(); break; } catch (e) {}
  }
  if (!targets) { console.error('FAIL devtools unreachable'); chrome.kill(); process.exit(1); }
  const pg = targets.find(t => t.type === 'page');
  const ws = new WebSocket(pg.webSocketDebuggerUrl);
  await new Promise(r => ws.onopen = r);
  let id = 0; const pending = new Map(); const errors = [];
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
    if (m.method === 'Runtime.exceptionThrown') errors.push('EXC ' + JSON.stringify(m.params.exceptionDetails.exception || m.params.exceptionDetails.text));
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push('CONSOLE ' + m.params.args.map(a => a.value || a.description).join(' '));
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') errors.push('LOG ' + m.params.entry.text);
  };
  const send = (method, params) => new Promise(res => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params: params || {} })); });
  const ev = async expr => (await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true })).result.result.value;
  await send('Runtime.enable'); await send('Log.enable'); await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
  await sleep(1200);
  for (const e of exprs) {
    try { console.log(JSON.stringify({ expr: e.slice(0, 60), value: await ev(e) })); }
    catch (err) { console.log(JSON.stringify({ expr: e.slice(0, 60), error: String(err.message || err) })); }
    await sleep(300);
  }
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(outPng, Buffer.from(shot.result.data, 'base64'));
  console.log('errors: ' + (errors.length ? errors.join(' | ') : 'NONE'));
  console.log('OK shot -> ' + outPng);
  await send('Browser.close').catch(() => {});
  ws.close(); chrome.kill(); process.exit(0);
}
main().catch(e => { console.error('FAIL ' + (e && e.message || e)); process.exit(1); });