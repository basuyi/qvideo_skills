// 通用源码抽取 → source-data.js（供"源码↔帧" retrospection 页展示真实代码）
// 用法: ELECTRON_RUN_AS_NODE=1 Qoder build-source.js <engine.js> <out.js> <fnNamesComma> [extraFilesComma]
// 输出 window.SOURCE = { fns:[{fn,code}], constants, extra:{basename:code} }
const fs = require('fs');
const path = require('path');
const [engine, out, fnArg, extraArg] = process.argv.slice(2);
if (!engine || !out || !fnArg) { console.error('usage: build-source.js <engine.js> <out.js> <fnNames> [extraFiles]'); process.exit(1); }
const src = fs.readFileSync(engine, 'utf8');
function extractFn(name) {
  const sig = 'function ' + name + '(';
  const i = src.indexOf(sig);
  if (i < 0) return '// (not found) ' + name;
  let k = src.indexOf('{', i), depth = 0;
  for (; k < src.length; k++) {
    if (src[k] === '{') depth++;
    else if (src[k] === '}') { depth--; if (!depth) { k++; break; } }
  }
  return src.slice(i, k);
}
const fns = fnArg.split(',').map(fn => ({ fn, code: extractFn(fn) }));
const marker = src.indexOf('/*');
const constants = src.slice(0, marker > 0 ? marker : Math.min(src.length, 2000));
const extra = {};
if (extraArg) for (const f of extraArg.split(',')) extra[path.basename(f)] = fs.readFileSync(f, 'utf8');
fs.writeFileSync(out, 'window.SOURCE = ' + JSON.stringify({ fns, constants, extra }, null, 1) + ';\n');
console.log('OK ' + out + '  ' + fns.length + ' fns, ' + Object.keys(extra).length + ' extra files, ' + fs.statSync(out).size + ' bytes');